# adapter_on_entity_typing

## Installation

Install Rust (dependency of `adapter-transformer`):
``` sh
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
```

Then, create a virtual environment and install required libraries:
``` sh
python3 -m venv venv
source venv/bin/activate
pip install -U pip
pip install -r requirements.txt
```
