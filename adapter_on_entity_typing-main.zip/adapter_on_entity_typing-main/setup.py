from setuptools import find_packages, setup
setup(
    name="adapter_entity_typing",
    packages=find_packages(include=('adapter_entity_typing')),
    version='0.1.0',
    description='package',
    author='Me',
)